package org.ngi.zhighcharts;

public class Version {
	/** Returns the version UID.
	 */
	public static final String UID = "0.2.0";
}
