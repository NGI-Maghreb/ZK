package ctrl;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.ngi.zhighcharts.SimpleExtXYModel;
import org.ngi.zhighcharts.ZHighCharts;
import org.zkoss.mesg.Messages;
import org.zkoss.util.logging.Log;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zul.Doublebox;
import org.zkoss.zul.Window;

public class NewDemoComposer extends Window implements EventListener {
	protected Log logger = Log.lookup(this.getClass());

	//Angular gauge
	private ZHighCharts chartComp1;
	private SimpleExtXYModel dataChartModel1 = new SimpleExtXYModel();
	
	//Gauge with dual axes
	private ZHighCharts chartComp2;
	private SimpleExtXYModel dataChartModel2 = new SimpleExtXYModel();
	
	
	private Doublebox doubleB;
	
	// date format used to capture date time
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");

	public void onCreate() throws Exception {
		
		//================================================================================
		// Angular gauge
	    //================================================================================
		
		chartComp1 = (ZHighCharts) getFellow("chartComp1");
		chartComp1.setType("gauge");
		chartComp1.setOptions("{" +
					"alignTicks: false," +
					"plotBackgroundColor: null," +
					"plotBackgroundImage: null," +
					"plotBorderWidth: 0," +
					"plotShadow: false" +
				"}");
		chartComp1.setTitle("Speedometer");
		chartComp1.setPane("{ " +
					"startAngle: -150, " +
					"endAngle: 150, " +
					"background: [" +
						"{ " +
							"backgroundColor: { " +
								"linearGradient: { " +
									"x1: 0, " +
									"y1: 0, " +
									"x2: 0, " +
									"y2: 1 " +
								"}, " +
								"stops: [ " +
									"[0, '#FFF'], " +
									"[1, '#333'] " +
								"] " +
							"}, " +
							"borderWidth: 0, " +
							"outerRadius: '109%' " +
						"}, " +
						"{ " +
							"backgroundColor: { " +
								"linearGradient: { " +
									"x1: 0, " +
									"y1: 0, " +
									"x2: 0, " +
									"y2: 1 " +
								"}, " +
								"stops: [ " +
									"[0, '#333'], " +
									"[1, '#FFF'] " +
								"] " +
							"}, " +
							"borderWidth: 1, " +
							"outerRadius: '107%' " +
						"}," +
						"{ " +// default background
						"}, " +
						"{ " +
							"backgroundColor: '#DDD', " +
							"borderWidth: 0, " +
							"outerRadius: '105%', " +
							"innerRadius: '103%' " +
						"}" +
					"] " +
				"}");
		
		chartComp1.setyAxisOptions("{ " +
					"min: 0, " +
					"max: 200,  " +
					"minorTickInterval: 'auto', " +
					"minorTickWidth: 1, " +
					"minorTickLength: 10, " +
					"minorTickPosition: 'inside', " +
					"minorTickColor: '#666',  " +
					"tickPixelInterval: 30, " +
					"tickWidth: 2, " +
					"tickPosition: 'inside', " +
					"tickLength: 10, " +
					"tickColor: '#666', " +
					"labels: { " +
						"step: 2, " +
						"rotation: 'auto' " +
					"}, " +
					"title: { " +
						"text: 'km/h' " +
					"}, " +
					"plotBands: [" +
						"{ " +
							"from: 0, " +
							"to: 120, " +
							"color: '#55BF3B' " + // green
						"}, " +
						"{ " +
							"from: 120, " +
							"to: 160, " +
							"color: '#DDDF0D' " + // yellow
						"}, " +
						"{ " +
							"from: 160, " +
							"to: 200, " +
							"color: '#DF5353' " + // red
						"}" +
					"] " +
				"}");
		
		chartComp1.setTooltipOptions("{enabled : false}");
		chartComp1.setModel(dataChartModel1);
		
		Map series = new HashMap();
        Map dataLabels = new HashMap();
        dataLabels.put("formatter", "function () { " +
        			"var kmh = this.y, mph = Math.round(kmh * 0.621);" +
        			"return '<span  style=\"color:#339\">'+ kmh + ' km/h</span><br/>" +
        			"' + '<span  style=\"color:#933\">' + mph + ' mph</span>';" +
        		"}");
        Map style = new HashMap();
        series.put("dataLabels", dataLabels);
        chartComp1.setSeriesOptions("Speed", series); 
        
		//Adding some data to the model
		dataChartModel1.addValue("Speed", 0, 20);		
		
		//================================================================================
	    // Gauge with dual axes
	    //================================================================================

		chartComp2 = (ZHighCharts) getFellow("chartComp2");
		chartComp2.setType("gauge");
		chartComp2.setOptions("{" +
					"alignTicks: false," +
					"plotBackgroundColor: null," +
					"plotBackgroundImage: null," +
					"plotBorderWidth: 0," +
					"plotShadow: false" +
				"}");
		chartComp2.setTitle("Speedometer with dual axes");
		chartComp2.setPane("{" +
					"startAngle: -150," +
					"endAngle: 150" +
				"}");
		chartComp2.setyAxisOptions("[" +
					"{ " +
						"min: 0, " +
						"max: 200, " +
						"lineColor: '#339', " +
						"tickColor: '#339', " +
						"minorTickColor: '#339', " +
						"offset: -25, " +
						"lineWidth: 2, " +
						"labels: { " +
							"distance: -20, " +
							"rotation: 'auto' " +
						"}, " +
						"tickLength: 5, " +
						"minorTickLength: 5, " +
						"endOnTick: false " +
					"}, " +
					"{ " +
						"min: 0, " +
						"max: 124, " +
						"tickPosition: 'outside', " +
						"lineColor: '#933', " +
						"lineWidth: 2, " +
						"minorTickPosition: 'outside', " +
						"tickColor: '#933', " +
						"minorTickColor: '#933', " +
						"tickLength: 5, " +
						"minorTickLength: 5, " +
						"labels: { " +
							"distance: 12, " +
							"rotation: 'auto' " +
						"}, " +
						"offset: -20, " +
						"endOnTick: false " +
					"}" +
				"]");
		chartComp2.setTooltipOptions("{enabled : false}");
//		chartComp2.setPlotOptions("{gauge:{animation : false}}");

		series = new HashMap();
        dataLabels = new HashMap();
        dataLabels.put("formatter", "function () { " +
        			"var kmh = this.y, mph = Math.round(kmh * 0.621);" +
        			"return '<span  style=\"color:#339\">'+ kmh + ' km/h</span><br/>" +
        			"' + '<span  style=\"color:#933\">' + mph + ' mph</span>';" +
        		"}");
        style = new HashMap();
        series.put("dataLabels", dataLabels);
        chartComp2.setSeriesOptions("Speed", series); 
		chartComp2.setModel(dataChartModel2);
		
		//Adding some data to the model
		dataChartModel2.addValue("Speed", 0, 20);		
		
		
		//Doublebox onOK Listener
		doubleB= (Doublebox) getFellow("doubleB");
		doubleB.addEventListener("onOK", this);
	}
	
	@Override
	public void onEvent(Event arg0) throws Exception {

		chartComp1.setGaugeValue(0, doubleB.getValue());
		chartComp2.setGaugeValue(0, doubleB.getValue());
	}

	/**
	 * internal method to convert date&time from string to epoch milliseconds
	 * 
	 * @param date
	 * @return
	 * @throws Exception
	 */
	private long getDateTime(String date) throws Exception {
		return sdf.parse(date).getTime();
	}

}
